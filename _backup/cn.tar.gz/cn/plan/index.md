--- 
published: true
layout: page
title: 计划
---
###（排名不分先后）预计完成时间<del>2012年12月31日</del> 暂时无法给出时间期限

**工作列表** 翻译GNU-GSL 写爬虫分析bucter论坛 

**学习列表** Perl系列丛书：<del>小骆驼</del>([完成](https://github.com/yulijia/Courses/blob/master/Perl/LearningPerl.pl "Learning Perl Scripts"))、大骆驼、精通，<del>统计建模与R软件（全部例题习题）</del>（放弃，做更有意义的事情）

**游戏列表** 建立流感病毒变异模型，分析传播趋势


