---
layout: page
title: Guestbook
comments: yes
---
##关于我

>您好！我白天是个学生，晚上就是个有抱负的科学家，这是我的博客。我住在天朝的帝都。   
以上纯属虚构，如有雷同，也不是小概率事件。

##修行之道

>关注大师的言行，跟随大师的举动，和大师一并修行，领会大师的意境，成为真正的大师。   
To follow the path, look to the master, follow the master, walk with the master, see through the master, become the master.

##箴言

>不要哀求，学会争取，若是如此，终有所获   
ねだるな、勝ち取れ、さすれば与えられん。   
Don’t beg for things, do it yourself or else you won’t get anything.

##欢迎留言:)
