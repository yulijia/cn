--- 
published: true
title: WordPress 现在真会卖萌
layout: post
author: Yu
category: 聚类不能
tag: WordPress

---
#欢迎使用 WordPress 3.3.2#

###感谢升级到最新版本！<span style="color: #008000;">*使用 WordPress 3.3.2 不仅可以让男生更帅，女生更美、改良人格，还可以大幅提升您的网上发布体验。*</span>诶，开玩笑的，其实她只能提升您的使用体验，但是光这一点就很不错了 :)###
