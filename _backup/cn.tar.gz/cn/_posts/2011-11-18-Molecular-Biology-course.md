--- 
published: true
title: 分子生物学课程有感
layout: post
author: Yu
category: 学在课堂
tags:
- DOT
- Molecular Biology

---
这门课是我学习的第一门英文教材、英文讲授的专业基础课。


这门课上有我见过的最多的同学演讲。


这门课所带给我的内容远大于书本上的知识。


分子生物学是我本学期选的一门生物类课程，课上英文（穿插中文）教学，所用教材是非常简单基础的[Molecular Biology Web Book](http://www.web-books.com/MoBio/ "Molecular Biology Web Book")。在课上许多同学都上台介绍分子生物学的相关知识，其实上课的时间多是学习同学介绍的内容，书本上的内容以课后自己阅读为主。王老师在课上还请来3为国外专家学者为我们做报告，介绍他们的研究内容。


初次上课发现自己远跟不上讲课的节奏，书上的专业词汇认识得几乎为零。但是上完所有课程之后，这些基本词汇已经掌握了。


这不，又选上了分子的讨论课。第一节课，又是一位外国学者（Chamindie Punyadeera）讲述自己的科研工作，是关于疾病检测的方法，她们实验室设计试剂盒，从唾液中检测同疾病有关的蛋白C-Reactive protein，这样可以避免抽血检测带来的不便。


第二次分子讨论课有人讨论到RNAi对HIV病毒疾病治疗的问题，这与DRACO广谱抗病毒的问题相关。


忘了放配图了，分子课最后一节，老师给我们介绍的学术代谢通路，一个科研工作者的一生。制作用的DOT，同原版相比略有差异。


<a href="http://i.imgur.com/9YK0e.png"><img title="The pathway of academic metabolism" src="http://i.imgur.com/9YK0e.png" alt="学术代谢通路" width="580" height="449" /></a>
