--- 
published: true
title: WordPress更新
layout: post
author: Yu
category: 聚类不能 
tags: WordPress

---
如题，今天更新到WordPress 3.3，提升用户体验。

>Thank you for updating to the latest version! Using WordPress 3.3 will<span style="color: #339966;"><strong> improve your looks, personality,</strong></span> and web publishing experience. Okay, just the last one, but still. <code>:)</code>


顺便更新了favicon.ico从之间的火星变成现在的字符（需要过一段时间才能显示）。


又到了一年中最忙的时候，很多考试，还有迎新活动。


P.S.: Google越来越强大了--&gt;  http://goo.gl/rLbi6
