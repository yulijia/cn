--- 
published: true
title: 世界，你好！
layout: post
author: Yu
category: 聚类不能
tags:
---
开博客。之前写程序时hello world!都不经过大脑翻译，这次在自己博客上看到hello world! 翻译成中文，竟没反应过来。

初次使用wordpress，博客的问题肯定不少，若各位看官发现问题，[请联系我](http://yulijia.github.com/cn/guestbook "留言板")。（P.S.: 若是IE6浏览器下的问题就算了）

另外感谢[刘指导](http://jimliu.net/ "刘指导")和小白蛇对博客技术和内容问题的指正。

感谢[Thomas](http://weibo.com/11978569 "@Thomas-sina.weibo")对无穷无尽的linux技术问题的帮助！
