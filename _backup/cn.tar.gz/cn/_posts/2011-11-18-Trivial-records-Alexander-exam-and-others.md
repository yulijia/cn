--- 
published: true
title: 琐碎记录：鸭梨山大的名言、考试及其他
layout: post
author: Yu
category: 生活点滴 
tags:

---
最近看了点Fate/Zero，结果网上有个比较搞笑的名言，[亚历山大](http://en.wikipedia.org/wiki/Alexander_the_Great "Alexander the Great")对将士们说：向东，向东，一定要赶在[麦哲伦](http://en.wikipedia.org/wiki/Ferdinand_Magellan "Ferdinand Magellan")之前。将一位公元前人物和一位公元后人物联系在一起的竟然是有些相似的梦想，一个想[征服东方](http://en.wikipedia.org/wiki/Wars_of_Alexander_the_Great "Wars of Alexander the Great")，一个想环游世界。区别是一个向东前进，一个向西进发。


最近每周考一门，一门接一门，一门接一门……生物专业的开卷考试就是要带越多的书越好，要不会找不到的，找不到的……闭卷考试背过的肯定不会考，肯定不会考……悲剧的数学老师有事停课，这一停，哪天考试就不得而知了，不得而知了……


昨天有同学过生日，给大家发棒棒糖，顿时感觉自己很老了，小朋友们还都很年轻啊，90后、89后一堆一堆的。悲剧的二战，我都快变成班里最大的了，要早点毕业啊@,@(2012.10.23 早点毕业破灭吧，没戏)


在学校用IPv6还是很方便的，把一些有用的Google网站地址加入hosts，还没是可以看看“你电视”的视频 XD
